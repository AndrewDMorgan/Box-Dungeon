from scripts.sound import Soundmanager
from Packages.PyVectors import *
import pygame, time

pygame.init()


def loadImage(file: str) -> pygame.Surface:
    image = pygame.image.load(file)
    size = Vec2(image.get_width(), image.get_height())
    surf = pygame.Surface(size)
    surf.fill((1, 1, 1))
    surf.blit(image, [0, 0])
    surf.convert()
    surf.set_colorkey((1, 1, 1))
    return surf


def Range(k: float, l: float, r: float):
    return k >= l and k < r


class UI:
    def text(screen: pygame.Surface, text: str, color: tuple, pos: tuple, size: float, center: bool = False, font: str = 'fonts/bubble.ttf'):
        size = math.floor(size / 1.5)
        largeText = pygame.font.Font(font, size)
        textSurface = largeText.render(text, True, color)
        TextSurf, TextRect = textSurface, textSurface.get_rect()
        if center:
            TextRect.center = pos
            sprite = screen.blit(TextSurf, TextRect)
        else:
            sprite = screen.blit(TextSurf, pos)
        return sprite 
    class Button:
        def __init__(self, pos: Vec2, sprites: dict, text: str, text_size: int, text_color: Vec3 = Vec3(0, 0, 0), text_offset: Vec2 = Vec2(0, 0)) -> None:
            self.pos = pos
            self.sprites = sprites
            self.size = {}
            for state in ['idle', 'held', 'pressed', 'hovered']:
                self.size[state] = Vec2(self.sprites[state].get_width(), self.sprites[state].get_height())
            self.half_size = {}
            for state in ['idle', 'held', 'pressed', 'hovered']:
                self.half_size[state] = self.size[state] // Vec2(2, 2)
            self.state = 'idle'
            self.text = text
            self.text_size = text_size
            self.text_offset = text_offset
            self.text_color = text_color
        def update(self, mouse_pos: Vec2, mouse_set: Vec2, mouse_down: bool, mouse_held: bool) -> None:
            if mouse_held:
                if mouse_set.x in range(self.pos.x - self.half_size[self.state].x, self.pos.x + self.half_size[self.state].x) and mouse_set.y in range(self.pos.y - self.half_size[self.state].y, self.pos.y + self.half_size[self.state].y):
                    self.state = 'held'
                else:
                    self.state = 'idle'
            elif self.state == 'held':
                self.state = 'pressed'
            elif mouse_pos.x in range(self.pos.x - self.half_size[self.state].x, self.pos.x + self.half_size[self.state].x) and mouse_pos.y in range(self.pos.y - self.half_size[self.state].y, self.pos.y + self.half_size[self.state].y):
                self.state = 'hovered'
            else:
                self.state = 'idle'
        def render(self, screen: pygame.Surface) -> None:
            screen.blit(self.sprites[self.state], self.pos - self.half_size[self.state])
            if self.state in ['pressed', 'held']:
                extra = Vec2(0, 3)
            else:
                extra = Vec2(0, 0)
            UI.text(screen, self.text, self.text_color, self.pos + self.text_offset + extra, self.text_size, center = True)


class Tile:
    def __init__(self, game, states, map) -> None:
        self.game = game
        self.tiles = states['sprites']
        self.speed = states['speed']
        self.length = len(self.tiles) - 1
        self.frame = 0
        self.map = map
    def __getitem__(self, key: int):
        self.frame += self.game.dt * self.speed
        if self.frame >= self.length:
            self.frame = 0
        return self.tiles[round(self.frame)]


class Map:
    def __init__(self, game, file: str, sprites: list, sprite_size: Vec2, animated_tiles: dict = {}) -> None:
        self.animated_tiles = animated_tiles
        self.sprites = sprites
        for i in range(len(self.sprites)):
            self.sprites[i] = loadImage(self.sprites[i])
        loaded_map = open(file).read().split('\n')
        self.map_size = Vec2(len(loaded_map[0].split(',')), len(loaded_map))  # generate correctly based on inputed map
        self.tiles = array(self.map_size, 'constant', None)
        Y = 0
        for y in loaded_map:
            X = 0
            for x in y.split(','):
                row_of_tiles = []
                for z in x.split('|'):
                    row_of_tiles.append(int(z))
                self.tiles[X][Y] = row_of_tiles
                X += 1
            Y += 1
        self.indexes = array(self.map_size.xy, 'constant', None)
        self.depths = array(self.map_size.xy, 'constant', None)
        for x in range(self.map_size.x):
            for y in range(self.map_size.y):
                layer_z = []
                for z in range(len(self.tiles[x][y])):
                    tile = self.tiles[x][y][z]
                    try:
                        animated_tiles[tile]
                        self.tiles[x][y][z] = Tile(game, animated_tiles[tile], self)
                    except KeyError:
                        self.tiles[x][y][z] = [tile]
                    layer_z.append(tile)
                self.indexes[x][y] = layer_z
                self.depths[x][y] = z + 1
        
        self.sprite_size = sprite_size
        self.scaled_sprites = []
        for sprite in self.sprites:
            self.scaled_sprites.append(sprite)
        self.scale = 1
        self.rescale(1)
        self.t_scale = self.sprite_size * Vec2(self.scale, self.scale)
    def rescale(self, new_scale: float) -> None:
        self.scale = new_scale
        self.t_scale = self.sprite_size * Vec2(self.scale, self.scale)
        sprite_size = round(self.sprite_size * Vec2(self.scale, self.scale))
        for i in range(len(self.sprites)):
            self.scaled_sprites[i] = pygame.transform.scale(self.sprites[i], sprite_size)
    def render(self, screen: pygame.Surface, camera_pos: Vec2, player_render_pos: Vec2, view_range: int = 10000000) -> None:
        res = Vec2(1200, 750)
        half_res = res // Vec2(2, 2)
        sprite_size = round(self.sprite_size * Vec2(self.scale, self.scale))
        tiles = ceil(res / sprite_size) + Vec2(2, 2)
        tiles_start = round((camera_pos - half_res) / sprite_size - Vec2(1, 1))
        if tiles_start.x < 0:
            offsetX = -tiles_start.x * sprite_size.x
            tiles_start = Vec2(0, tiles_start.y)
        else:
            offsetX = 0
        if tiles_start.y < 0:
            offsetY = -tiles_start.y * sprite_size.y
            tiles_start = Vec2(tiles_start.x, 0)
        else:
            offsetY = 0
        if tiles_start.x + tiles.x > self.map_size.x:
            tiles = Vec2(tiles.x - ((tiles_start.x + tiles.x) - (self.map_size.x)), tiles.y)
        if tiles_start.y + tiles.y > self.map_size.y:
            tiles = Vec2(tiles.x, tiles.y - ((tiles_start.y + tiles.y) - (self.map_size.y)))
        
        offsetX -= math.fract((camera_pos.x - half_res.x) / sprite_size.x + 0.5) * sprite_size.x
        offsetY -= math.fract((camera_pos.y - half_res.y) / sprite_size.y + 0.5) * sprite_size.y
        
        left_half  = round(player_render_pos) - Vec2(view_range, view_range)
        right_half = round(player_render_pos) + Vec2(view_range, view_range)

        X = offsetX
        for x in range(tiles_start.x, tiles_start.x + tiles.x):
            Y = offsetY
            for y in range(tiles_start.y, tiles_start.y + tiles.y):
                for z in range(self.depths[x][y]):
                    good = True
                    if self.tiles[x][y][z][0] in [32, 33, 34, 35]:
                        good = round(X) in range(left_half.x, right_half.x) and round(Y) in range(left_half.y, right_half.y)
                    if good:
                        sprite = self.scaled_sprites[self.tiles[x][y][z][0]]
                        screen.blit(sprite, [X, Y])
                Y += sprite_size.y
            X += sprite_size.x


def CreateTile(tile_map: Map, pos: Vec2, tile) -> None:
    if pos.z >= len(tile_map.tiles[pos.x][pos.y]):  # preventing errors
        tile_map.tiles[pos.x][pos.y].append(None)  # preventing errors
        if pos.z >= len(tile_map.tiles[pos.x][pos.y]):  # preventing errors
            pos = Vec3(pos.x, pos.y, len(tile_map.tiles[pos.x][pos.y]) - 1)  # preventing errors
    try:
        tile_map.animated_tiles[tile]
        tile_map.tiles[pos.x][pos.y][pos.z] = Tile(tile_map.animated_tiles[tile], tile_map)
    except KeyError:
        tile_map.tiles[pos.x][pos.y][pos.z] = [tile]


def ConvertCoord(pos: Vec2, camera_pos: Vec2, tile_map: Map) -> Vec2:
    return round((pos + camera_pos) / tile_map.t_scale)


def main(tile_map):
    # renderer
    camera_pos = vec2(0, 0)
    player_speed = 600
    scale = 1

    # selected tile
    current_tile = 0

    # editor
    layer = 0

    res = vec2(1200, 750)
    half_res = res // vec2(2)

    screen = pygame.display.set_mode(res)

    held = {'w': False, 'a': False, 's': False, 'd': False, 'up': False, 'down': False, 'mouse_down': False, 'mouse_up': False, 'mouse_held': False}
    mouse_set = vec2(-20)
    dt = 1

    running = True

    while running:
        st = time.time()
        mouse_pos = Vec2(pygame.mouse.get_pos()[0], pygame.mouse.get_pos()[1])
        held['mouse_up'] = False
        held['mouse_down'] = False
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                pygame.quit()
                break
            elif event.type == pygame.KEYDOWN:
                if   event.key == ord('w'):
                    held['w'] = True
                elif event.key == ord('a'):
                    held['a'] = True
                elif event.key == ord('s'):
                    held['s'] = True
                elif event.key == ord('d'):
                    held['d'] = True
                elif event.key == pygame.K_UP:
                    held['up'] = True
                elif event.key == pygame.K_DOWN:
                    held['down'] = True
                elif event.key == pygame.K_RIGHT:
                    current_tile += 1
                    if current_tile > len(tile_map.sprites) - 1:
                        current_tile -= 1
                elif event.key == pygame.K_LEFT:
                    current_tile -= 1
                    if current_tile < 0:
                        current_tile = 0
                elif event.key == ord('k'):
                    print(round((mouse_pos - half_res + camera_pos) / tile_map.t_scale))
            elif event.type == pygame.KEYUP:
                if   event.key == ord('w'):
                    held['w'] = False
                elif event.key == ord('a'):
                    held['a'] = False
                elif event.key == ord('s'):
                    held['s'] = False
                elif event.key == ord('d'):
                    held['d'] = False
                elif event.key == pygame.K_UP:
                    held['up'] = False
                elif event.key == pygame.K_DOWN:
                    held['down'] = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    held['mouse_down'] = True
                    held['mouse_held'] = True
                    mouse_set = mouse_pos
            elif event.type == pygame.MOUSEBUTTONUP:
                if event.button == 1:
                    held['mouse_up'] = True
                    held['mouse_held'] = False
        
        if not running:
            break
        
        acelleration = Vec2(0, 0)
        if held['w']:
            acelleration += Vec2(0 , -1)
        if held['a']:
            acelleration += Vec2(-1, 0 )
        if held['s']:
            acelleration += Vec2(0 , 1 )
        if held['d']:
            acelleration += Vec2(1 , 0 )
        
        """
        if held['up']:
            scale += 0.1
            tile_map.rescale(scale)
        if held['down']:
            scale -= 0.1
            scale = max(scale, 0.05)
            tile_map.rescale(scale)
        """
        
        if held['mouse_up']:
            # this grabs the coord(s)
            tile_pos_tl = round((mouse_set - half_res + camera_pos) / tile_map.t_scale) - Vec2(1, 1)
            tile_pos_br = round((mouse_pos - half_res + camera_pos) / tile_map.t_scale)
            if mouse_set.x > mouse_pos.x:
                tile_pos_tl, tile_pos_br = Vec2(tile_pos_br.x - 1, tile_pos_tl.y), Vec2(tile_pos_tl.x + 1, tile_pos_br.y)
            if mouse_set.y > mouse_pos.y:
                tile_pos_tl, tile_pos_br = Vec2(tile_pos_tl.x, tile_pos_br.y - 1), Vec2(tile_pos_br.x, tile_pos_tl.y + 1)
            
            tile_pos_tl = Vec2(math.clamp(tile_pos_tl.x, 0, tile_map.map_size.x), math.clamp(tile_pos_tl.y, 0, tile_map.map_size.y))
            tile_pos_br = Vec2(math.clamp(tile_pos_br.x, 0, tile_map.map_size.x), math.clamp(tile_pos_br.y, 0, tile_map.map_size.y))

            # change to fill with the specified tile
            for x in range(tile_pos_tl.x, tile_pos_br.x):
                for y in range(tile_pos_tl.y, tile_pos_br.y):
                    tile = current_tile
                    CreateTile(tile_map, Vec3(x, y, layer), tile)
                    tile_map.indexes[x][y] = [tile]

        acelleration *= Vec2(dt, dt)
        camera_pos += acelleration * Vec2(player_speed, player_speed)
        
        screen.fill(vec3(225))

        tile_map.render(screen, camera_pos, Vec2(-200, -200))

        screen.blit(tile_map.sprites[max(current_tile - 1, 0)], [10, 40])
        screen.blit(tile_map.sprites[current_tile], [74, 40])
        screen.blit(tile_map.sprites[min(current_tile + 1, len(tile_map.sprites) - 1)], [138, 40])
        surf = pygame.Surface((64, 64))
        surf.fill((200, 200, 200))
        screen.blit(surf, [74, 40], special_flags = pygame.BLEND_RGB_MULT)
        UI.text(screen, 'FPS: ' + str(round(1 / dt, 2)), Vec3(0, 0, 0), Vec2(10, 10), 25)
        
        pygame.display.update()

        et = time.time()
        dt = et - st

    string = ''
    for x in tile_map.indexes:
        Y = 0
        y_depth = len(x)
        for y in x:
            z_depth = len(y)
            Z = 0
            for z in y:
                string += str(z)
                if Z < z_depth - 1:
                    string += '|'
                Z += 1
            if Y < y_depth - 1:
                string += ','
            Y += 1
        string += '\n'
    print(string)

