from scripts.map_renderer import ConvertCoord, Map, main, UI
from Packages.PyVectors import *
from scripts.sound import Sound
import pygame, time, random
import pyautogui

pygame.init()

"""
bug:

    updates suddenly (when you return to the screen)
    not velocity
    is player pos and camera pos
    makes collition wired
    can make the player do a small jump
    only happens when you go to a different window

"""


def render_credits(screen: pygame.Surface) -> None:
    UI.text(screen, 'Composer And Sound Designer - manhsterz@gmail.com', (0, 0, 35), (10, 725), 35 * 1.5, font = 'fonts/pixel.ttf')
    UI.text(screen, 'Game Developer - andrewDaGamer741@gmail.com', (0, 0, 35), (10, 700), 35 * 1.5, font = 'fonts/pixel.ttf')
    UI.text(screen, 'Artist - noam8486@gmail.com', (0, 0, 35), (10, 675), 35 * 1.5, font = 'fonts/pixel.ttf')


def checkCollide(tile_map: Map, coord: Vec2) -> bool:
    try:
        for tile in tile_map.indexes[coord.x][coord.y]:
            if tile != 0:
                return False
        return True
    except IndexError:
        return True


def LoadImage(file: str) -> pygame.Surface:
    image = pygame.image.load(file)
    size = Vec2(image.get_width(), image.get_height())
    surf = pygame.Surface(size)
    surf.fill((1, 1, 1))
    surf.blit(image, [0, 0])
    surf.convert()
    surf.set_colorkey((1, 1, 1))
    return surf


class GameStates:
    game = 'IN_GAME'
    main_menu = "ON_MAIN_MENU"
    settings_menu = 'ON_SETTINGS_MENU'
    pause_menu = 'ON_PAUSE_MENU'
    level_select = 'ON_LEVEL_SELECT_MENU'
    won_menu = 'YOU_WON_MENU'


class Derections:
    right = 'RIGHT'
    left = 'LEFT'


# a similar class to the animation class
class Entity:
    def __init__(self, states: dict, pos: Vec2, state: str = 'idle') -> None:
        self.pos = pos
        self.states = states
        self.state = state
        self.size = self.states['size']
        self.frame = 0
    def update(self, dt: float) -> None:
        self.frame += dt * self.states['speed'][self.state]
        if self.frame >= len(self.states['sprites'][self.state]):
            self.frame = 0
    def render(self, screen: pygame.Surface, camera_pos: Vec2) -> None:
        screen.blit(self.states['sprites'][self.state][math.floor(self.frame)], self.pos - self.size / Vec2(2, 2) - camera_pos)


class Turret (Entity):
    def __init__(self, states: dict, pos: Vec2, state: str = 'idle', proj_sprite_file: str = 'None', derection: Vec2 = Vec2(0, 0)) -> None:
        super().__init__(states, pos, state = state)
        self.projectile_sprite = pygame.transform.scale(LoadImage(proj_sprite_file), (32, 32))
        self.projes = []
        self.derection = derection
        self.last_shot = time.time()
        self.glow_sprite = pygame.transform.scale(LoadImage('sprites/cannon/glow.png'), (128, 128))
    def update(self, camera_pos: Vec2, tile_map: Map, dt: float, player_pos: Vec2, difficulty: int) -> None:
        super().update(dt)
        
        self.frame = math.clamp(math.map(time.time() - self.last_shot, 0, difficulty / 4 + 0.75, 0, 4), 0, 4)
        
        if time.time() - self.last_shot > difficulty / 4 + 0.75:
            proj = TurretProjectile(self.pos, self.projectile_sprite, self.derection, self.glow_sprite)
            self.projes.append(proj)
            self.last_shot = time.time()
            if length((self.pos - Vec2(600, 375)) - player_pos) <= 400:
                s = Sound('sounds/cannon_shoot.mp3', channel = 3)
                s * (1 - length((self.pos - Vec2(600, 375)) - player_pos) / 400)
                s.play()
        i = 0
        n_projes = self.projes[:]
        for proj in self.projes:
            proj.update(dt, camera_pos, tile_map)
            if proj.life_time < 0:
                del n_projes[i]
                i -= 1
            i += 1
        self.projes = n_projes
    def render(self, screen: pygame.Surface, camera_pos: Vec2) -> None:
        for proj in self.projes:
            proj.render(screen, camera_pos)
        super().render(screen, camera_pos)


class TurretProjectile (Entity):  # animate turret when shooting
    def __init__(self, pos: Vec2, sprite: pygame.Surface, derection: Vec2, glow_sprite: pygame.Surface) -> None:
        super().__init__(states={
                                    "size": Vec2(32, 32),
                                    "speed":
                                    {
                                        "base": 0
                                    },
                                    "sprites":
                                    {
                                        "base":
                                        [
                                            sprite
                                        ]
                                    }
                                }, pos = pos, state = 'base')
        self.derection = derection
        self.life_time = 15  # just a safty net
        self.glow_sprite = glow_sprite
    def update(self, dt: float, camera_pos, tile_map) -> None:
        super().update(dt)
        self.life_time -= dt
        change = self.derection * Vec2(dt, dt)
        col1 = checkCollide(tile_map, ConvertCoord(self.pos - Vec2(600, 750) + Vec2(-32 + self.derection.x / 15, 256 + 96 + self.derection.y / 15) + change, Vec2(0, 0), tile_map))
        col2 = checkCollide(tile_map, ConvertCoord(self.pos - Vec2(600, 750) + Vec2(-32 + self.derection.x / 15, 256 + 96 + self.derection.y / 15) + change / Vec2(2, 2), Vec2(0, 0), tile_map))
        if col1 and col2:
            self.pos += change
        else:
            self.life_time = -1
    def render(self, screen: pygame.Surface, camera_pos: Vec2) -> None:
        render_pos = floor(self.pos - Vec2(64, 64) - camera_pos)
        if render_pos.x in range(-64, 1264) and render_pos.y in range(-64, 814):
            super().render(screen, camera_pos)
            screen.blit(self.glow_sprite, render_pos, special_flags = pygame.BLEND_RGB_MULT)


class Portal:
    def __init__(self, pos: Vec2) -> None:
        self.sprites =  [
                            pygame.transform.scale(LoadImage('sprites/portal/portal.png'), (32, 32))
                        ]
        self.size = Vec2(self.sprites[0].get_width(), self.sprites[0].get_height())
        self.half_size = self.size // Vec2(2, 2)
        self.pos = pos
        self.frame = 0
    def update(self, dt: float, player_pos: Vec2) -> bool:
        self.frame += dt * 6
        if self.frame > 0:
            self.frame = 0
        if round(player_pos.x + 600) in range(self.pos.x - self.half_size.x, self.pos.x + self.half_size.x) and round(player_pos.y + 375) in range(self.pos.y - self.half_size.y, self.pos.y + self.half_size.y):
            return True
        else:
            return False
    def render(self, screen: pygame.Surface, camera_pos: Vec2) -> None:
        screen.blit(self.sprites[math.floor(self.frame)], self.pos - self.half_size - camera_pos)


class Platform:
    def __init__(self, path: list, sprite: pygame.Surface, speed: float) -> None:
        self.path = path
        self.speed = speed
        self.point_on_path = 0
        self.pos = self.path[0]
        self.sprite = sprite
        self.size = Vec2(self.sprite.get_width(), self.sprite.get_height())
        self.half_size = self.size // Vec2(2, 2)
        self.following_player = False
    def update(self, dt: float) -> None:
        last_pos = self.pos.copy()
        self.point_on_path += dt * self.speed
        if self.point_on_path >= len(self.path) - 1:  # yes this is correct (stops 1 item early because there is an extra item to avoid an index error)
            self.point_on_path = 0
        self.pos = mix(self.path[math.floor(self.point_on_path)], self.path[math.ceil(self.point_on_path)], math.fract(self.point_on_path))
        change = self.pos - last_pos
        return change
    def render(self, screen: pygame.Surface, camera_pos: Vec2) -> None:
        screen.blit(self.sprite, self.pos - self.half_size - camera_pos)
    def collide(self, position: Vec2) -> bool:
        pos = round(self.pos) - Vec2(600, 375)
        return position.x in range(pos.x - self.half_size.x, pos.x + self.half_size.x) and position.y in range(pos.y - self.half_size.y, pos.y + self.half_size.y)


class Main:
    def __init__(self) -> None:
        self.res = Vec2(1200, 750)
        
        self.__Rscreen = pygame.display.set_mode((1200, 750))
        self.map = Map(self, 'tile_maps/map1.map',  [
                                                        'sprites/tiles/sprite_-1.png',
                                                        'sprites/tiles/sprite_-1.png',
                                                        'sprites/tiles/Ground00.png',
                                                        'sprites/tiles/Ground01.png',
                                                        'sprites/tiles/Ground02.png',
                                                        'sprites/tiles/Ground03.png',
                                                        'sprites/tiles/Ground04.png',
                                                        'sprites/tiles/Ground05.png',
                                                        'sprites/tiles/Ground06.png',
                                                        'sprites/tiles/Ground07.png',
                                                        'sprites/tiles/Ground08.png',
                                                        'sprites/tiles/Ground09.png',
                                                        'sprites/tiles/Ground10.png',
                                                        'sprites/tiles/Ground11.png',
                                                        'sprites/tiles/Ground12.png',
                                                        'sprites/tiles/Ground13.png',
                                                        'sprites/tiles/Ground14.png',
                                                        'sprites/tiles/sprite_00.png',
                                                        'sprites/tiles/sprite_01.png',
                                                        'sprites/tiles/sprite_02.png',
                                                        'sprites/tiles/sprite_03.png',
                                                        'sprites/tiles/sprite_04.png',
                                                        'sprites/tiles/sprite_05.png',
                                                        'sprites/tiles/sprite_06.png',
                                                        'sprites/tiles/sprite_07.png',
                                                        'sprites/tiles/sprite_08.png',
                                                        'sprites/tiles/sprite_09.png',
                                                        'sprites/tiles/sprite_10.png',
                                                        'sprites/tiles/sprite_11.png',
                                                        'sprites/tiles/sprite_12.png',
                                                        'sprites/tiles/sprite_13.png',
                                                        'sprites/tiles/sprite_14.png',
                                                        'sprites/tiles/sprite_15.png',
                                                        'sprites/tiles/sprite_16.png',
                                                        'sprites/tiles/sprite_17.png',
                                                        'sprites/tiles/sprite_18.png'
                                                    ], Vec2(32, 32), animated_tiles = {})
        self.__spike_tiles = [32, 33, 34, 35]
        self.__door_tiles = []
        self.level = 0

        # remove the following in export
        #main(self.map)
        pygame.init()
        
        self.screen = pygame.Surface((1200, 750))
        self.__in_full_screen = False
        self.full_screen_res = vectorize(pyautogui.size())

        self.reses = [floor(self.full_screen_res // Vec2(2, 2)), floor(self.full_screen_res // Vec2(1.75, 1.75)), floor(self.full_screen_res // Vec2(1.5, 1.5)), floor(self.full_screen_res // Vec2(1.25, 1.25)), self.full_screen_res]
        self.res = self.reses[3]
        self.__Rscreen = pygame.display.set_mode(self.res)

        self.state = GameStates.main_menu
        self.camera_pos = Vec2(100, 100)
        self.player_pos = Vec2(100, 100)
        self.held = {'left': None, 'right': None, 'up': None, 'down': None}
        self.down = {'left': None, 'right': None, 'up': None, 'down': None}
        self.up   = {'left': None, 'right': None, 'up': None, 'down': None}
        self.dt = 0

        self.player_sprites={
                                "sprites":
                                {
                                    "running":
                                    [
                                        LoadImage('sprites/player/Run02.png'),
                                        LoadImage('sprites/player/Run03.png'),
                                        LoadImage('sprites/player/Run04.png'),
                                        LoadImage('sprites/player/Run05.png')
                                    ],
                                    "idle":
                                    [
                                        LoadImage('sprites/player/Idle00.png'),
                                        LoadImage('sprites/player/Idle01.png')
                                    ],
                                    "jumping":
                                    [
                                        LoadImage('sprites/player/Jumping06.png')
                                    ],
                                    "falling":
                                    [
                                        LoadImage('sprites/player/Falling07.png')
                                    ],
                                    "hit":
                                    [
                                        LoadImage('sprites/player/Hit08.png'),
                                        LoadImage('sprites/player/Hit09.png'),
                                        LoadImage('sprites/player/Hit10.png'),
                                        LoadImage('sprites/player/Hit10.png')
                                    ]
                                },
                                "speed":
                                {
                                    "running": 6,
                                    "idle"   : 2,
                                    "jumping": 0,
                                    "falling": 0,
                                    "hit"    : 8
                                }
                            }
        self.player_frame = 0
        self.player_derection = Derections.right
        self.player_velY = 0
        self.falling = -5
        self.player_lives = 3
        self.player_live_colldown = -5
        self.player_state = 'idle'
        self.spawn_point = Vec2(100, 100)
        self.player_jump_sound = ['sounds/player_jumping.mp3', 'sounds/player_jumping1.mp3', 'sounds/player_jumping2.mp3']
        self.walking_sounds = ['sounds/footsteps/step1.mp3', 'sounds/footsteps/step2.mp3', 'sounds/footsteps/step3.mp3', 'sounds/footsteps/step4.mp3', 'sounds/footsteps/step5.mp3']
        self.health = [LoadImage('sprites/health/Health bar0.png'), LoadImage('sprites/health/Health bar1.png'), LoadImage('sprites/health/Health bar2.png'), LoadImage('sprites/health/Health bar3.png')]
        for i in range(len(self.health)):
            self.health[i] = pygame.transform.scale(self.health[i], round(Vec2(48 * 1.5, 48 * 1.5)))
        
        self.player_glow = pygame.transform.scale(LoadImage('sprites/player/player_glow.png'), (128 + 64, 128 + 64))

        turret_dict1 =   {
                            "size": Vec2(32, 32),
                            "speed":
                            {
                                "idle": 0
                            },
                            "sprites":
                            {
                                "idle":
                                [
                                    pygame.transform.scale(LoadImage("sprites/cannon/sprite_25.png"), (32, 32)),
                                    pygame.transform.scale(LoadImage("sprites/cannon/sprite_29.png"), (32, 32)),
                                    pygame.transform.scale(LoadImage("sprites/cannon/sprite_33.png"), (32, 32)),
                                    pygame.transform.scale(LoadImage("sprites/cannon/sprite_37.png"), (32, 32)),
                                    pygame.transform.scale(LoadImage("sprites/cannon/sprite_41.png"), (32, 32))
                                ]
                            }
                        }
        turret_dict2 =   {
                            "size": Vec2(32, 32),
                            "speed":
                            {
                                "idle": 0
                            },
                            "sprites":
                            {
                                "idle":
                                [
                                    pygame.transform.scale(LoadImage("sprites/cannon/sprite_23.png"), (32, 32)),
                                    pygame.transform.scale(LoadImage("sprites/cannon/sprite_27.png"), (32, 32)),
                                    pygame.transform.scale(LoadImage("sprites/cannon/sprite_31.png"), (32, 32)),
                                    pygame.transform.scale(LoadImage("sprites/cannon/sprite_35.png"), (32, 32)),
                                    pygame.transform.scale(LoadImage("sprites/cannon/sprite_39.png"), (32, 32))
                                ]
                            }
                        }
        turret_dict3 =  {
                            "size": Vec2(32, 32),
                            "speed":
                            {
                                "idle": 0
                            },
                            "sprites":
                            {
                                "idle":
                                [
                                    pygame.transform.scale(LoadImage("sprites/cannon/sprite_24.png"), (32, 32)),
                                    pygame.transform.scale(LoadImage("sprites/cannon/sprite_28.png"), (32, 32)),
                                    pygame.transform.scale(LoadImage("sprites/cannon/sprite_32.png"), (32, 32)),
                                    pygame.transform.scale(LoadImage("sprites/cannon/sprite_36.png"), (32, 32)),
                                    pygame.transform.scale(LoadImage("sprites/cannon/sprite_40.png"), (32, 32))
                                ]
                            }
                        }
        turret_dict4 =  {
                            "size": Vec2(32, 32),
                            "speed":
                            {
                                "idle": 0
                            },
                            "sprites":
                            {
                                "idle":
                                [
                                    pygame.transform.scale(LoadImage("sprites/cannon/sprite_26.png"), (32, 32)),
                                    pygame.transform.scale(LoadImage("sprites/cannon/sprite_30.png"), (32, 32)),
                                    pygame.transform.scale(LoadImage("sprites/cannon/sprite_34.png"), (32, 32)),
                                    pygame.transform.scale(LoadImage("sprites/cannon/sprite_38.png"), (32, 32)),
                                    pygame.transform.scale(LoadImage("sprites/cannon/sprite_42.png"), (32, 32))
                                ]
                            }
                        }
        self.turrets =  [
                            Turret(turret_dict2, Vec2(600 + 128 + 32                    , 599 - 128 - 32               ), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict1, Vec2(600 + 128 + 32 + 256 * 4 + 5  * 32, 599 - 128 - 32 + 15 * 32 - 64), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_19.png', derection = Vec2(0   , -200)),
                            Turret(turret_dict1, Vec2(600 + 128 + 32 + 256 * 4 + 14 * 32, 599 - 128 - 32 + 15 * 32 - 64), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_19.png', derection = Vec2(0   , -200)),
                            Turret(turret_dict1, Vec2(600 + 128 + 32 + 256 * 4 + 33 * 32, 599 - 128 - 32 + 15 * 32 - 64), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_19.png', derection = Vec2(0   , -200)),
                            Turret(turret_dict3, Vec2(600 + 128 + 32 + 256 * 4 + 2  * 32, 599 - 128 - 32               ), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_22.png', derection = Vec2(200 , 0   )),
                            Turret(turret_dict2, Vec2(600 + 128 + 32 + 256 * 4 + 4  * 32, 599 - 128 - 32 + 37 * 32     ), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(600 + 128 + 32 + 256 * 4 + 7  * 32, 599 - 128 - 32 + 37 * 32     ), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(600 + 128 + 32 + 256 * 4 + 10 * 32, 599 - 128 - 32 + 37 * 32     ), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(600 + 128 + 32 + 256 * 4 + 13 * 32, 599 - 128 - 32 + 37 * 32     ), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(600 + 128 + 32 + 256 * 4 + 16 * 32, 599 - 128 - 32 + 37 * 32     ), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict4, Vec2(600 + 27 * 32, 375 + 45 * 32), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_20.png', derection = Vec2(-200, 0   )),
                            Turret(turret_dict2, Vec2(600 + 14 * 32, 375 + 25 * 32), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(600 + 20 * 32, 375 + 25 * 32), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(600 + 26 * 32, 375 + 25 * 32), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(600 + 32 * 32, 375 + 25 * 32), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(600 + 8  * 32, 375 + 66 * 32), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(600 + 21 * 32, 375 + 66 * 32), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(600 + 32 * 32, 375 + 66 * 32), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict4, Vec2(600 + 48 * 32, 375 + 64 * 32), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_20.png', derection = Vec2(-200, 0   )),
                            Turret(turret_dict3, Vec2(600 + 39 * 32, 375 + 60 * 32), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_22.png', derection = Vec2(200 , 0   )),
                            Turret(turret_dict4, Vec2(600 + 48 * 32, 375 + 55 * 32), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_20.png', derection = Vec2(-200, 0   )),
                            Turret(turret_dict2, Vec2(600 + 56 * 32, 375 + 76 * 32), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(600 + 59 * 32, 375 + 76 * 32), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(600 + 62 * 32, 375 + 76 * 32), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(600 + 65 * 32, 375 + 76 * 32), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(600 + 68 * 32, 375 + 76 * 32), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict4, Vec2(600 + 73 * 32, 375 + 74 * 32), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_20.png', derection = Vec2(-200, 0   )),
                            Turret(turret_dict2, Vec2(600 + 57 * 32, 375 + 71 * 32), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(600 + 66 * 32, 375 + 71 * 32), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict3, Vec2(600 + 41 * 32, 375 + 91 * 32), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_22.png', derection = Vec2(200 , 0   )),
                            Turret(turret_dict3, Vec2(600 + 41 * 32, 375 + 91 * 32), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_22.png', derection = Vec2(200 , 0   )),
                            Turret(turret_dict3, Vec2(600 + 41 * 32, 375 + 91 * 32), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_22.png', derection = Vec2(200 , 0   )),
                            Turret(turret_dict3, Vec2(600 + 41 * 32, 375 + 91 * 32), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_22.png', derection = Vec2(200 , 0   )),
                            Turret(turret_dict3, Vec2(600 + 41 * 32, 375 + 91 * 32), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_22.png', derection = Vec2(200 , 0   )),
                            Turret(turret_dict3, Vec2(600 + 41 * 32, 375 + 91 * 32), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_22.png', derection = Vec2(200 , 0   )),
                            Turret(turret_dict3, Vec2(600 + 41 * 32, 375 + 91 * 32), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_22.png', derection = Vec2(200 , 0   )),
                            Turret(turret_dict4, Vec2(28, 91) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_20.png', derection = Vec2(-200, 0   )),
                            Turret(turret_dict3, Vec2(9, 91) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_22.png', derection = Vec2(200 , 0   )),
                            Turret(turret_dict2, Vec2(11, 86) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(17, 86) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(24, 86) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict4, Vec2(36, 86) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_20.png', derection = Vec2(-200, 0   )),
                            Turret(turret_dict2, Vec2(24, 71) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(49, 66) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(5 , 94 ) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(13, 94 ) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(20, 94 ) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(26, 94 ) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(32, 101) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(17, 101) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(9 , 101) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(7 , 108) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(15, 108) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(22, 108) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(31, 108) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(55, 102) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(61, 102) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(67, 102) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(64, 117) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(60, 117) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(52, 117) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(46, 117) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(47, 128) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(58, 128) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(68, 128) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(32, 132) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(28, 132) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(22, 132) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(18, 132) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(13, 132) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(9 , 132) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(31, 117) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(18, 117) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict4, Vec2(31, 137) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_20.png', derection = Vec2(-200, 0   )),
                            Turret(turret_dict4, Vec2(23, 137) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_20.png', derection = Vec2(-200, 0   )),
                            Turret(turret_dict4, Vec2(14, 137) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_20.png', derection = Vec2(-200, 0   )),
                            Turret(turret_dict1, Vec2(52, 107) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_19.png', derection = Vec2(0   , -200)),
                            Turret(turret_dict1, Vec2(58, 107) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_19.png', derection = Vec2(0   , -200)),
                            Turret(turret_dict1, Vec2(64, 107) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_19.png', derection = Vec2(0   , -200)),

                            Turret(turret_dict2, Vec2(9 , 140) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(22, 140) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(34, 140) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(31, 163) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(29, 163) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(25, 163) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(19, 163) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(15, 163) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(53, 157) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(48, 157) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(43, 157) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(73, 140) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(64, 140) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(55, 140) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(49, 140) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(35, 157) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(30, 157) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(24, 157) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(16, 157) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(9 , 157) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(7 , 150) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(12, 150) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(19, 150) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(25, 150) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict2, Vec2(30, 150) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_21.png', derection = Vec2(0   , 200 )),
                            Turret(turret_dict1, Vec2(40, 175) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_19.png', derection = Vec2(0   , -200)),
                            Turret(turret_dict1, Vec2(42, 175) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_19.png', derection = Vec2(0   , -200)),
                            Turret(turret_dict1, Vec2(44, 175) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_19.png', derection = Vec2(0   , -200)),
                            Turret(turret_dict1, Vec2(46, 175) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_19.png', derection = Vec2(0   , -200)),
                            Turret(turret_dict1, Vec2(48, 175) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_19.png', derection = Vec2(0   , -200)),
                            Turret(turret_dict1, Vec2(50, 175) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_19.png', derection = Vec2(0   , -200)),
                            Turret(turret_dict1, Vec2(52, 175) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_19.png', derection = Vec2(0   , -200)),

                            Turret(turret_dict4, Vec2(11, 176) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_20.png', derection = Vec2(-200, 0   )),
                            Turret(turret_dict4, Vec2(11, 173) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_20.png', derection = Vec2(-200, 0   )),
                            Turret(turret_dict4, Vec2(11, 169) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_20.png', derection = Vec2(-200, 0   )),
                            Turret(turret_dict4, Vec2(11, 166) * Vec2(32, 32) + Vec2(600, 375), state = 'idle', proj_sprite_file = 'sprites/cannon/sprite_20.png', derection = Vec2(-200, 0   )),
                        ]

        self.platforms =[
                            Platform([Vec2(1032 , 599), Vec2(1664, 599), Vec2(1032 , 599)], pygame.transform.scale(LoadImage('sprites/tiles/platform.png'), (96, 20)), 0.2),
                            Platform([Vec2(600, 375) + Vec2(26, 63) * Vec2(32, 32), Vec2(600, 375) + Vec2(13, 61) * Vec2(32, 32), Vec2(600, 375) + Vec2(26, 63) * Vec2(32, 32)], pygame.transform.scale(LoadImage('sprites/tiles/platform.png'), (96, 20)), 0.2),
                            Platform([Vec2(6, 98) * Vec2(32, 32) + Vec2(600, 375), Vec2(34, 98) * Vec2(32, 32) + Vec2(600, 375), Vec2(35, 105) * Vec2(32, 32) + Vec2(600, 375), Vec2(3, 105) * Vec2(32, 32) + Vec2(600, 375), Vec2(3, 113) * Vec2(32, 32) + Vec2(600, 375), Vec2(31, 113) * Vec2(32, 32) + Vec2(600, 375), Vec2(3, 113) * Vec2(32, 32) + Vec2(600, 375), Vec2(3, 105) * Vec2(32, 32) + Vec2(600, 375), Vec2(35, 105) * Vec2(32, 32) + Vec2(600, 375), Vec2(34, 98) * Vec2(32, 32) + Vec2(600, 375), Vec2(6, 98) * Vec2(32, 32) + Vec2(600, 375)], pygame.transform.scale(LoadImage('sprites/tiles/platform.png'), (96, 20)), 0.05),
                            Platform([Vec2(40, 113) * Vec2(32, 32) + Vec2(600, 375), Vec2(41, 97) * Vec2(32, 32) + Vec2(600, 375), Vec2(40, 113) * Vec2(32, 32) + Vec2(600, 375)], pygame.transform.scale(LoadImage('sprites/tiles/platform.png'), (96, 20)), 0.3),
                            Platform([Vec2(69, 165) * Vec2(32, 32) + Vec2(600, 375), Vec2(69, 183) * Vec2(32, 32) + Vec2(600, 375), Vec2(65, 183) * Vec2(32, 32) + Vec2(600, 375), Vec2(65, 166) * Vec2(32, 32) + Vec2(600, 375), Vec2(61, 166) * Vec2(32, 32) + Vec2(600, 375), Vec2(61, 183) * Vec2(32, 32) + Vec2(600, 375), Vec2(57, 183) * Vec2(32, 32) + Vec2(600, 375), Vec2(57, 166) * Vec2(32, 32) + Vec2(600, 375), Vec2(57, 183) * Vec2(32, 32) + Vec2(600, 375), Vec2(61, 183) * Vec2(32, 32) + Vec2(600, 375), Vec2(61, 166) * Vec2(32, 32) + Vec2(600, 375), Vec2(65, 166) * Vec2(32, 32) + Vec2(600, 375), Vec2(65, 183) * Vec2(32, 32) + Vec2(600, 375), Vec2(69, 183) * Vec2(32, 32) + Vec2(600, 375), Vec2(69, 165) * Vec2(32, 32) + Vec2(600, 375)], pygame.transform.scale(LoadImage('sprites/tiles/platform.png'), (96, 20)), 0.15)
                        ]
        
        self.in_game_music = Sound('sounds/Score_Space_Jam_31_Level_Music_OldFuturistic.mp3', loops = -1, fade_ms = 250, channel = 0)
        self.in_menu_music = Sound('sounds/Score_Space_Jam_31_MENU_theme.mp3', loops = -1, fade_ms = 250, channel = 1)
        self.in_menu_music.play()
        
        self.mouse_pos = Vec2(-10, -10)
        self.mouse_set = Vec2(-10, -10)
        self.mouse_down = False
        self.mouse_up = False
        self.mouse_held = False
        self.mouse_scaler = Vec2(1200, 750) / self.res

        button_sprites ={
                            "idle"   : pygame.transform.scale(LoadImage('sprites/ui/button0.png'), (200, 80)),
                            "hovered": pygame.transform.scale(LoadImage('sprites/ui/button0.png'), (220, 90)),
                            "held"   : pygame.transform.scale(LoadImage('sprites/ui/button1.png'), (200, 80)),
                            "pressed": pygame.transform.scale(LoadImage('sprites/ui/button1.png'), (200, 80))
                        }
        # change to new buttons
        level_button_sprites =  {
                                    "idle"   : pygame.transform.scale(LoadImage('sprites/ui/button2.png'), (72, 92 )),
                                    "hovered": pygame.transform.scale(LoadImage('sprites/ui/button2.png'), (82, 108)),
                                    "held"   : pygame.transform.scale(LoadImage('sprites/ui/button3.png'), (72, 92 )),
                                    "pressed": pygame.transform.scale(LoadImage('sprites/ui/button3.png'), (72, 92 ))
                                }

        self.main_menu_buttons =[
                                    UI.Button(Vec2(575, 235), button_sprites, 'PLAY'    , 35, text_offset = Vec2(0, -2)),
                                    UI.Button(Vec2(625, 330), button_sprites, 'SETTINGS', 35, text_offset = Vec2(0, -2))
                                ]
        
        self.old_room = Vec2(0, 0)

        self.button_click_sound = Sound('sounds/button_clicked.mp3', channel = 2, fade_ms = 5)
        self.difficulty = 2

        self.portals =  [
                            Portal(Vec2(600 + 64, 375 + 64 + 27 * 32)),
                            Portal(Vec2(2, 74) * Vec2(32, 32) + Vec2(600, 375)),
                            Portal(Vec2(36, 119) * Vec2(32, 32) + Vec2(600, 375)),
                            Portal(Vec2(3, 164) * Vec2(32, 32) + Vec2(600, 375))
                        ]

        self.won_menu_buttons = [
                                    UI.Button(Vec2(650, 300), button_sprites, 'NEXT', 35, text_offset = Vec2(0, -2)),
                                    UI.Button(Vec2(600, 400), button_sprites, 'REDO', 35, text_offset = Vec2(0, -2)),
                                    UI.Button(Vec2(550, 500), button_sprites, 'MENU', 35, text_offset = Vec2(0, -2))
                                ]
        
        self.pause_menu_buttons=[
                                    UI.Button(Vec2(575, 325), button_sprites, 'RESUME', 35, text_offset = Vec2(0, -2)),
                                    UI.Button(Vec2(625, 425), button_sprites, 'MENU', 35, text_offset = Vec2(0, -2)),
                                ]

        self.background_image = LoadImage('sprites/ui/BG (1).png')
        self.play_jingle = -20

        self.level_select_buttons = [
                                        UI.Button(Vec2(450, 300), level_button_sprites, '1', 35),
                                        UI.Button(Vec2(550, 300), level_button_sprites, '2', 35),
                                        UI.Button(Vec2(650, 300), level_button_sprites, '3', 35),
                                        UI.Button(Vec2(750, 300), level_button_sprites, '4', 35)
                                    ]
        
        self.level_start_time = 0
        self.score = -1
        self.deaths = 0
        self.level_time_taken = -1

        self.dark_surf = pygame.Surface((1200, 750))
        self.dark_surf.fill((175, 175, 175))
    def update(self) -> None:
        frame_start = time.time()
        # floor the mouse set and pos when creating them
        self.mouse_pos = floor(vectorize(pygame.mouse.get_pos()) * self.mouse_scaler)
        self.mouse_down = False
        self.mouse_up = False

        set_state = self.state
        for key in self.down:
            self.down[key] = False
            self.up[key] = False
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                global running
                running = False
                pygame.quit()
                return None
            elif event.type == pygame.KEYDOWN:
                if event.key in [ord('w'), pygame.K_UP]:
                    self.down['up'] = True
                    self.held['up'] = True
                elif event.key in [ord('a'), pygame.K_LEFT]:
                    self.down['left'] = True
                    self.held['left'] = True
                elif event.key in [ord('s'), pygame.K_DOWN]:
                    self.down['down'] = True
                    self.held['down'] = True
                elif event.key in [ord('d'), pygame.K_RIGHT]:
                    self.down['right'] = True
                    self.held['right'] = True
                elif event.key == pygame.K_ESCAPE:
                    if self.state == GameStates.settings_menu:
                        set_state = GameStates.main_menu
                    elif self.state == GameStates.pause_menu:
                        set_state = GameStates.game
                    elif self.state == GameStates.game:
                        set_state = GameStates.pause_menu
                    elif self.state == GameStates.level_select:
                        set_state = GameStates.main_menu
            elif event.type == pygame.KEYUP:
                if event.key in [ord('w'), pygame.K_UP]:
                    self.up['up'] = True
                    self.held['up'] = False
                elif event.key in [ord('a'), pygame.K_LEFT]:
                    self.up['left'] = True
                    self.held['left'] = False
                elif event.key in [ord('s'), pygame.K_DOWN]:
                    self.up['down'] = True
                    self.held['down'] = False
                elif event.key in [ord('d'), pygame.K_RIGHT]:
                    self.up['right'] = True
                    self.held['right'] = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    self.mouse_down = True
                    self.mouse_held = True
                    self.mouse_set = self.mouse_pos
            elif event.type == pygame.MOUSEBUTTONUP:
                if event.button == 1:
                    self.mouse_up = True
                    self.mouse_held = False

        if self.state == GameStates.game:
            p2 = round(self.player_pos) + Vec2(18 , -16)
            p3 = round(self.player_pos) + Vec2(-18, -16)
            p4 = round(self.player_pos) + Vec2(-18, 16 )
            p5 = round(self.player_pos) + Vec2(18 , 16 )
            p6 = round(self.player_pos) + Vec2(18 , 0  )
            p7 = round(self.player_pos) + Vec2(-18, 0  )
            for platform in self.platforms:
                change = platform.update(self.dt)
                if platform.following_player or platform.collide(p2) or platform.collide(p3) or platform.collide(p4) or platform.collide(p5) or platform.collide(p6) or platform.collide(p7):
                    self.player_pos += change
                platform.following_player = False
            
            if (self.held['left'] or self.held['right']) and random.randint(0, math.floor(5000 * self.dt)) == 0:
                s = Sound(self.walking_sounds[random.randint(0, 4)], channel = 4)
                s.play()

            speed = 300
            if self.player_state != 'hit':
                self.player_state = 'idle'
                if self.falling < 0:
                    self.player_state = 'falling'
                elif self.player_velY > 0:
                    self.player_state = 'jumping'
            if self.held['left']:
                if self.player_state != 'hit':
                    self.player_state = 'running'
                np = self.player_pos + Vec2(-speed, 0   ) * Vec2(self.dt, self.dt)
                self.player_derection = Derections.left
                con1 = checkCollide(self.map, ConvertCoord(np - Vec2(48, 48), Vec2(0, 0), self.map))
                con2 = checkCollide(self.map, ConvertCoord(np - Vec2(48, 16), Vec2(0, 0), self.map))

                coord = ConvertCoord(np - Vec2(48, 48), Vec2(0, 0), self.map)
                try:
                    for tile in self.map.indexes[coord.x][coord.y]:
                        if tile in self.__spike_tiles and self.player_live_colldown <= 0:
                            self.player_lives -= 1
                            Sound('sounds/hit_by_spike.mp3', channel = 2, fade_ms = 5).play()
                            self.player_live_colldown = 0.5
                            self.player_velY = 500
                            self.player_state = 'hit'
                            self.player_frame = 0
                            break
                except IndexError:
                    pass
                coord = ConvertCoord(np - Vec2(48, 16), Vec2(0, 0), self.map)
                try:
                    for tile in self.map.indexes[coord.x][coord.y]:
                        if tile in self.__spike_tiles and self.player_live_colldown <= 0:
                            self.player_lives -= 1
                            Sound('sounds/hit_by_spike.mp3', channel = 2, fade_ms = 5).play()
                            self.player_live_colldown = 0.5
                            self.player_velY = 500
                            self.player_state = 'hit'
                            self.player_frame = 0
                            break
                except IndexError:
                    pass
                
                platform_collided = False
                platform_collide_index = 0
                np_2 = round(np) + Vec2(18, -15)
                for platform in self.platforms:
                    if platform.collide(np_2):
                        platform_collided = True
                        break
                    platform_collide_index += 1
                if not platform_collided:
                    platform_collided = False
                    platform_collide_index = 0
                    np_2 = round(np) + Vec2(18, 15)
                    for platform in self.platforms:
                        if platform.collide(np_2):
                            platform_collided = True
                            break
                        platform_collide_index += 1
                    if not platform_collided:
                        platform_collided = False
                        platform_collide_index = 0
                        np_2 = round(np) + Vec2(-18, 15)
                        for platform in self.platforms:
                            if platform.collide(np_2):
                                platform_collided = True
                                break
                            platform_collide_index += 1
                        if not platform_collided:
                            platform_collided = False
                            platform_collide_index = 0
                            np_2 = round(np) + Vec2(-18, -15)
                            for platform in self.platforms:
                                if platform.collide(np_2):
                                    platform_collided = True
                                    break
                                platform_collide_index += 1
                            if not platform_collided:
                                platform_collided = False
                                platform_collide_index = 0
                                np_2 = round(np) + Vec2(-18, 0)
                                for platform in self.platforms:
                                    if platform.collide(np_2):
                                        platform_collided = True
                                        break
                                    platform_collide_index += 1
                                if not platform_collided:
                                    platform_collided = False
                                    platform_collide_index = 0
                                    np_2 = round(np) + Vec2(18, 0)
                                    for platform in self.platforms:
                                        if platform.collide(np_2):
                                            platform_collided = True
                                            break
                                        platform_collide_index += 1

                if con1 and con2 and not platform_collided:
                    self.player_pos = np
                elif platform_collided:
                    self.platforms[platform_collide_index].following_player = True
            if self.held['right']:
                if self.player_state != 'hit':
                    self.player_state = 'running'
                np = self.player_pos + Vec2(speed , 0   ) * Vec2(self.dt, self.dt)
                self.player_derection = Derections.right
                con1 = checkCollide(self.map, ConvertCoord(np - Vec2(16 , 48), Vec2(0, 0), self.map))
                con2 = checkCollide(self.map, ConvertCoord(np - Vec2(16 , 16), Vec2(0, 0), self.map))

                coord = ConvertCoord(np - Vec2(16 , 16), Vec2(0, 0), self.map)
                try:
                    for tile in self.map.indexes[coord.x][coord.y]:
                        if tile in self.__spike_tiles and self.player_live_colldown <= 0:
                            self.player_lives -= 1
                            Sound('sounds/hit_by_spike.mp3', channel = 2, fade_ms = 5).play()
                            self.player_live_colldown = 0.5
                            self.player_velY = 500
                            self.player_state = 'hit'
                            self.player_frame = 0
                            break
                except IndexError:
                    pass
                coord = ConvertCoord(np - Vec2(16 , 48), Vec2(0, 0), self.map)
                try:
                    for tile in self.map.indexes[coord.x][coord.y]:
                        if tile in self.__spike_tiles and self.player_live_colldown <= 0:
                            self.player_lives -= 1
                            Sound('sounds/hit_by_spike.mp3', channel = 2, fade_ms = 5).play()
                            self.player_live_colldown = 0.5
                            self.player_velY = 500
                            self.player_state = 'hit'
                            self.player_frame = 0
                            break
                except IndexError:
                    pass

                platform_collided = False
                platform_collide_index = 0
                np_2 = round(np) + Vec2(18, -15)
                for platform in self.platforms:
                    if platform.collide(np_2):
                        platform_collided = True
                        break
                    platform_collide_index += 1
                if not platform_collided:
                    platform_collided = False
                    platform_collide_index = 0
                    np_2 = round(np) + Vec2(18, 15)
                    for platform in self.platforms:
                        if platform.collide(np_2):
                            platform_collided = True
                            break
                        platform_collide_index += 1
                    if not platform_collided:
                        platform_collided = False
                        platform_collide_index = 0
                        np_2 = round(np) + Vec2(-18, 15)
                        for platform in self.platforms:
                            if platform.collide(np_2):
                                platform_collided = True
                                break
                            platform_collide_index += 1
                        if not platform_collided:
                            platform_collided = False
                            platform_collide_index = 0
                            np_2 = round(np) + Vec2(-18, -15)
                            for platform in self.platforms:
                                if platform.collide(np_2):
                                    platform_collided = True
                                    break
                                platform_collide_index += 1
                            if not platform_collided:
                                platform_collided = False
                                platform_collide_index = 0
                                np_2 = round(np) + Vec2(-18, 0)
                                for platform in self.platforms:
                                    if platform.collide(np_2):
                                        platform_collided = True
                                        break
                                    platform_collide_index += 1
                                if not platform_collided:
                                    platform_collided = False
                                    platform_collide_index = 0
                                    np_2 = round(np) + Vec2(18, 0)
                                    for platform in self.platforms:
                                        if platform.collide(np_2):
                                            platform_collided = True
                                            break
                                        platform_collide_index += 1
                
                if con1 and con2 and not platform_collided:
                    self.player_pos = np
                elif platform_collided:
                    self.platforms[platform_collide_index].following_player = True
            if self.held['up'] and self.falling >= 0:
                if self.player_velY < 400:
                    Sound(self.player_jump_sound[random.randint(0, 2)], channel = 1).play()
                self.player_velY = 500
            
            self.falling -= self.dt * 20
            self.player_frame += self.dt * self.player_sprites['speed'][self.player_state]
            if self.player_frame >= len(self.player_sprites['sprites'][self.player_state]):
                self.player_frame = 0
                if self.player_state == 'hit':
                    self.player_state = 'idle'

            self.player_velY -= self.dt * 2200

            np = self.player_pos - Vec2(0, self.player_velY) * Vec2(self.dt, self.dt)
            con1 = checkCollide(self.map, ConvertCoord(np - Vec2(48, 48), Vec2(0, 0), self.map))
            con2 = checkCollide(self.map, ConvertCoord(np - Vec2(48, 16), Vec2(0, 0), self.map))
            con3 = checkCollide(self.map, ConvertCoord(np - Vec2(16 , 48), Vec2(0, 0), self.map))
            con4 = checkCollide(self.map, ConvertCoord(np - Vec2(16 , 16), Vec2(0, 0), self.map))
            
            platform_collided = False
            platform_collide_index = 0
            np_2 = round(np) + Vec2(-16, -16)
            for platform in self.platforms:
                if platform.collide(np_2):
                    platform_collided = True
                    break
                platform_collide_index += 1
            if not platform_collided:
                platform_collided = False
                platform_collide_index = 0
                np_2 = round(np) + Vec2(16, -16)
                for platform in self.platforms:
                    if platform.collide(np_2):
                        platform_collided = True
                        break
                    platform_collide_index += 1
                if not platform_collided:
                    platform_collided = False
                    platform_collide_index = 0
                    np_2 = round(np) + Vec2(-16, 16)
                    for platform in self.platforms:
                        if platform.collide(np_2):
                            platform_collided = True
                            break
                        platform_collide_index += 1
                    if not platform_collided:
                        platform_collided = False
                        platform_collide_index = 0
                        np_2 = round(np) + Vec2(16, 16)
                        for platform in self.platforms:
                            if platform.collide(np_2):
                                platform_collided = True
                                break
                            platform_collide_index += 1

            if con1 and con2 and con3 and con4 and not platform_collided:
                self.player_pos = np
            else:
                if platform_collided:
                    self.platforms[platform_collide_index].following_player = True
                if self.player_velY < 0:
                    self.player_velY = max(self.player_velY, 0)
                    self.falling = 5
                else:
                    self.player_velY = min(self.player_velY, 0)
                    self.falling = -10
            
            coord = ConvertCoord(np - Vec2(32, 16), Vec2(0, 0), self.map) - Vec2(0, 1)
            try:
                for tile in self.map.indexes[coord.x][coord.y]:
                    if tile in self.__spike_tiles and self.player_live_colldown <= 0:
                        self.player_lives -= 1
                        Sound('sounds/hit_by_spike.mp3', channel = 2, fade_ms = 5).play()
                        self.player_live_colldown = 0.5
                        self.player_velY = -500
                        self.player_state = 'hit'
                        self.player_frame = 0
                        break
            except IndexError:
                pass
            coord = ConvertCoord(np - Vec2(32, 48), Vec2(0, 0), self.map) + Vec2(0, 1)
            try:
                for tile in self.map.indexes[coord.x][coord.y]:
                    if tile in self.__spike_tiles and self.player_live_colldown <= 0:
                        self.player_lives -= 1
                        Sound('sounds/hit_by_spike.mp3', channel = 2, fade_ms = 5).play()
                        self.player_live_colldown = 0.5
                        self.player_velY = 500
                        self.player_state = 'hit'
                        self.player_frame = 0
                        break
            except IndexError:
                pass
            
            for turret in self.turrets:
                turret.update(self.camera_pos, self.map, self.dt, self.player_pos, self.difficulty)
            
            for portal in self.portals:
                ended_level = portal.update(self.dt, self.player_pos)
                if ended_level:
                    Sound('sounds/won_game.mp3', channel = 4).play()
                    self.play_jingle = 50
                    self.player_velY = 0
                    self.player_pos = Vec2(100, 100)
                    self.spawn_point = self.player_pos.copy()
                    self.level_time_taken = time.time() - self.level_start_time
                    self.score = math.clamp(1000 - (self.level_time_taken) * 6 - self.deaths * 50 + (4 - self.difficulty - 2) * 50, 0, 1100)
                    self.deaths = 0
                    self.camera_pos = self.player_pos.copy()
                    set_state = GameStates.won_menu
                    self.in_menu_music.play()
                    self.in_game_music.stop(250)
                    self.player_lives = 3
                    for turret in self.turrets:
                        turret.projes = []
                    for platform in self.platforms:
                        platform.point_on_path = 0

            self.camera_pos = floor(mix(self.camera_pos, floor(self.player_pos / Vec2(37 * 32, 23 * 32)) * Vec2(37 * 32, 23 * 32) + Vec2(620, 395), self.dt * 12))
            new_room = floor(self.player_pos.copy() / Vec2(37 * 32, 23 * 32))
            if self.old_room.x != new_room.x or self.old_room.y != new_room.y:
                self.spawn_point = self.player_pos.copy() + (new_room - self.old_room) * Vec2(16, 16)
            self.old_room = floor(self.player_pos.copy() / Vec2(37 * 32, 23 * 32))

            if length(self.camera_pos) > 10000:
                self.player_velY = 0
                self.camera_pos = Vec2(0, 0)
                self.player_pos = Vec2(100, 100)
                self.spawn_point = self.player_pos.copy()
        elif self.state == GameStates.main_menu:
            for button in self.main_menu_buttons:
                button.update(self.mouse_pos, self.mouse_set, self.mouse_down, self.mouse_held)
                if button.state == 'pressed':
                    self.button_click_sound.play()
                    if button.text == 'PLAY':
                        set_state = GameStates.level_select
                    elif button.text == 'SETTINGS':
                        set_state = GameStates.settings_menu
        elif self.state == GameStates.settings_menu:
            pygame.draw.rect(self.screen, (150, 150, 165), [500, 100, 200, 100])
            if self.mouse_down:
                if self.mouse_pos.x in range(500, 700) and self.mouse_pos.y in range(200, 300):
                    self.button_click_sound.play()
                    ind = math.clamp((self.mouse_pos.y - 200) // 20, 0, 4)
                    self.res = self.reses[ind]
                    self.mouse_scaler = Vec2(1200, 750) / self.res
                    if ind == 4:
                        self.__Rscreen = pygame.display.set_mode(self.res, pygame.FULLSCREEN)
                    else:
                        self.__Rscreen = pygame.display.set_mode(self.res)
                elif self.mouse_pos.x in range(500, 700) and self.mouse_pos.y in range(400, 500):
                    self.button_click_sound.play()
                    self.difficulty = math.clamp((self.mouse_pos.y - 400) // 20, 0, 4)
        elif self.state == GameStates.won_menu:
            self.play_jingle -= self.dt * 5
            if self.play_jingle > 0 and self.play_jingle < 5:
                # this sound plays at a bad time so it isnt very useful
                #Sound('sounds/portal_teleported.mp3', channel = 2).play()
                self.play_jingle = -5
            for button in self.won_menu_buttons:
                button.update(self.mouse_pos, self.mouse_set, self.mouse_down, self.mouse_held)
                if button.state == 'pressed':
                    self.button_click_sound.play()
                    if button.text == 'NEXT':
                        self.in_game_music.play()
                        self.in_menu_music.stop(250)
                        self.level += 1
                        set_state = GameStates.game
                        self.spawn_point = Vec2(100, 100 + 46 * 32 * self.level)
                        self.deaths = 0
                        self.level_start_time = time.time()
                        self.player_pos = self.spawn_point.copy()
                    elif button.text == 'REDO':
                        set_state = GameStates.game
                        self.in_game_music.play()
                        self.in_menu_music.stop(250)
                        self.deaths = 0
                        self.level_start_time = time.time()
                    elif button.text == 'MENU':
                        set_state = GameStates.main_menu
        elif self.state == GameStates.pause_menu:
            for button in self.pause_menu_buttons:
                button.update(self.mouse_pos, self.mouse_set, self.mouse_down, self.mouse_held)
                if button.state == 'pressed':
                    if button.text == 'RESUME':
                        set_state = GameStates.game
                    elif button.text == 'MENU':
                        set_state = GameStates.main_menu
                        self.in_menu_music.play()
                        self.in_game_music.stop(250)
                        self.player_velY = 0
                        self.player_pos = Vec2(100, 100)
                        self.spawn_point = self.player_pos.copy()
                        self.camera_pos = self.player_pos.copy()
                        self.player_lives = 3
                        for turret in self.turrets:
                            turret.projes = []
                        for platform in self.platforms:
                            platform.point_on_path = 0
        elif self.state == GameStates.level_select:
            for button in self.level_select_buttons:
                button.update(self.mouse_pos, self.mouse_set, self.mouse_down, self.mouse_held)
                if button.state == 'pressed':
                    self.button_click_sound.play()
                    self.level = int(button.text) - 1
                    set_state = GameStates.game
                    self.in_game_music.play()
                    self.in_menu_music.stop(250)
                    self.player_pos = Vec2(100, 100 + 46 * 32 * self.level)
                    self.deaths = 0
                    self.level_start_time = time.time()
                    self.spawn_point = self.player_pos.copy()

        self.screen.fill(vec3(225))

        if self.state == GameStates.game:
            #self.screen.fill(vec3(125))
            self.screen.blit(pygame.transform.flip(self.background_image, False, False), [(1200 - self.camera_pos.x % 1200) - 1200, (750 - self.camera_pos.y % 750)      ])
            self.screen.blit(pygame.transform.flip(self.background_image, False, True ), [(1200 - self.camera_pos.x % 1200) - 1200, (750 - self.camera_pos.y % 750) - 750])
            self.screen.blit(pygame.transform.flip(self.background_image, True , True ), [(1200 - self.camera_pos.x % 1200)       , (750 - self.camera_pos.y % 750) - 750])
            self.screen.blit(pygame.transform.flip(self.background_image, True , False), [(1200 - self.camera_pos.x % 1200)       , (750 - self.camera_pos.y % 750)      ])
            player_render_pos = round(self.player_pos - self.camera_pos + Vec2(600, 375) - Vec2(16, 16))
            self.map.render(self.screen, self.camera_pos, player_render_pos, view_range = [64, 96, 128, 256, 512][self.difficulty])

            self.screen.blit(self.dark_surf, (0, 0), special_flags = pygame.BLEND_RGB_MULT)

            for portal in self.portals:
                portal.render(self.screen, self.camera_pos)

            if self.player_lives < 0:
                self.deaths += 1
                self.player_lives = 3
                self.player_pos = self.spawn_point
                self.player_velY = 0
                self.player_live_colldown = 2

            self.screen.blit(self.health[3 - math.floor(self.player_lives)], (600 - 36, 0))

            for platform in self.platforms:
                platform.render(self.screen, self.camera_pos)

            for turret in self.turrets:
                turret.render(self.screen, self.camera_pos)

            sprite = self.player_sprites['sprites'][self.player_state][math.floor(self.player_frame)]

            if self.player_derection == Derections.left:
                sprite = pygame.transform.flip(sprite, True, False)
            sprite = pygame.transform.scale(sprite, (32, 32))
            
            self.screen.blit(sprite, player_render_pos)
            
            self.screen.blit(self.player_glow, player_render_pos - Vec2(48 + 32, 48 + 32), special_flags = pygame.BLEND_RGB_MULT)

            self.player_live_colldown -= self.dt
            player_pos2 = round(self.player_pos) + Vec2(616, 391)
            player_pos3 = round(self.player_pos) + Vec2(584, 391)
            player_pos4 = round(self.player_pos) + Vec2(616, 359)
            player_pos5 = round(self.player_pos) + Vec2(584, 359)
            for turret in self.turrets:
                for proj in turret.projes:
                    proj_pos = proj.pos
                    c1 = round(proj_pos.x + 16) in range(player_pos2.x, player_pos2.x + 32) and round(proj_pos.y + 16) in range(player_pos2.y, player_pos2.y + 32)
                    c2 = round(proj_pos.x + 16) in range(player_pos3.x, player_pos3.x + 32) and round(proj_pos.y + 16) in range(player_pos3.y, player_pos3.y + 32)
                    c3 = round(proj_pos.x + 16) in range(player_pos4.x, player_pos4.x + 32) and round(proj_pos.y + 16) in range(player_pos4.y, player_pos4.y + 32)
                    c4 = round(proj_pos.x + 16) in range(player_pos5.x, player_pos5.x + 32) and round(proj_pos.y + 16) in range(player_pos5.y, player_pos5.y + 32)
                    if c1 or c2 or c3 or c4:
                        if self.player_live_colldown <= 0:
                            self.player_lives -= 1
                            self.player_live_colldown = 1.25
                            self.player_velY = 800
                            if proj.derection.y > 0:
                                self.player_velY *= -1
                            self.player_state = 'hit'
                            self.player_frame = 0
                            s = Sound('sounds/player_hit_cannon.mp3', channel = 4)
                            s.play()
        elif self.state == GameStates.main_menu:
            for button in self.main_menu_buttons:
                button.render(self.screen)
            render_credits(self.screen)
        elif self.state == GameStates.settings_menu:
            pygame.draw.rect(self.screen, (150, 150, 165), [500, 200, 200, 100])
            pygame.draw.rect(self.screen, (100, 100, 125), [500, self.reses.index(self.res) * 20 + 200, 200, 20])
            Y = 210
            for res in self.reses:
                UI.text(self.screen, f'{res.x}x{res.y}', (0, 0, 35), (600, Y), 25, center = True)
                Y += 20
            
            pygame.draw.rect(self.screen, (150, 150, 165), [500, 400, 200, 100])
            pygame.draw.rect(self.screen, (100, 100, 125), [500, self.difficulty * 20 + 400, 200, 20])
            Y = 410
            for diff in ['Hardcore', 'Hard', 'Normal', 'Easy', 'Ultra Easy']:
                UI.text(self.screen, diff, (0, 0, 35), (600, Y), 25, center = True)
                Y += 20

            render_credits(self.screen)
        elif self.state == GameStates.won_menu:
            UI.text(self.screen, 'Victory!', (0, 0, 35), (600, 100), 130, center = True)
            UI.text(self.screen, f'Score: {round(self.score)}', (0, 0, 35), (600, 155), 40, center = True)
            for button in self.won_menu_buttons:
                button.render(self.screen)
            render_credits(self.screen)
        elif self.state == GameStates.pause_menu:
            for button in self.pause_menu_buttons:
                button.render(self.screen)
            render_credits(self.screen)
        elif self.state == GameStates.level_select:
            UI.text(self.screen, 'Select A Level', (0, 0, 35), (600, 125), 75, center = True)
            for button in self.level_select_buttons:
                button.render(self.screen)
            render_credits(self.screen)

        if self.dt != 0:
            UI.text(self.screen, f'FPS: {round(1 / self.dt, 2)}', Vec3(0, 0, 0), Vec2(10, 10), 35)

        self.__Rscreen.blit(pygame.transform.scale(self.screen, self.res), [0, 0])
        pygame.display.update()

        self.state = set_state

        frame_end = time.time()
        self.dt = frame_end - frame_start


running = True
game = Main()

while running:
    game.update()

